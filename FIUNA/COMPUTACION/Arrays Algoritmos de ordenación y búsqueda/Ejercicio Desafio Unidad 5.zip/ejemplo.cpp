#include <iostream>

using namespace std;

void ordenamientoEscalera(int* A,int fi){
 //Completar
}

// No modificar desde aqui
void leerElementos(int *A,int fi){
    srand(1);
    for(int i=0;i<fi;i++){
        for(int j=0;j<fi;j++){
           cin>>*(A+(i*fi)+j);
        }
    }
}
// No modificar 
void mostrarElementos(int* A,int fi){
    for(int i=0;i<fi;i++){
        cout<<endl;
        for(int j=0;j<fi;j++){
            cout<<*(A+(i*fi)+j)<<" ";
        }
    }
}
// No modificar 
int main()
{
    int n;
    cin>>n;
    int matriz[n][n];
    leerElementos(matriz[0],n);
    ordenamientoEscalera(matriz[0],n);
    cout<<endl;
    mostrarElementos(matriz[0],n);
    return 0;
}