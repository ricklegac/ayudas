#include<iostream>
using namespace std;
int main()

{
      float m,n,temp1,k;
      int i, j;
      cin>>m>>n;
      float A[int(m)][int(n)];
      //no modificar ingreso de la matriz
      for(i=0;i<m;i++)
      {
                      for(j=0;j<n;j++)
                      {
                                      cin>>A[i][j];
                      }
      }
      //realizar aqui el metodo de ordenacion que mejor les parezca
      
      
      
      
                    //Impresion de la matriz no modificar
                    for(i=0;i<m;i++)
                    {
                                    for(j=0;j<n;j++)
                                                    {
                                                                   cout<<A[i][j]<<"  ";
                                                    }
                                    cout<<"\n";
                    }
}
      
