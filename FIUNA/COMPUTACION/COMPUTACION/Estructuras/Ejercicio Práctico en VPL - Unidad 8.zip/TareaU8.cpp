#include <iostream>
/**
Crear una estructura de datos Alumno para calcular la nota final (NF) 
de los 5 alumnos del curso Programacion, así como también el promedio, 
el mínimo y el máximo de las notas. 
Leer por teclado el código del alumno y los puntajes parciales (P1 y P2) 
y puntaje final (EF) de cada uno de éstos (enteros de 0 a 100, validar)

El puntaje final se calcula empleando la fórmula: PF = 0.6*PP + 0.4*EF
En donde PP es el promedio de parciales: PP = (P1+P2)/2

La nota final (NF) se determina mediante la siguiente tabla:
0-59 Nota 1
60-70 Nota 2
71-80 Nota 3
81-90 Nota 4
91-100 Nota 5

El cálculo de la Nota Final, el Promedio de las calificaciones así como 
la mayor y menor nota deben realizarse a través de funciones.
*/
using namespace std;
int N = 0;

//agregue la estructura

int calcularNotaFinal(int PF) {
	//complete la funcion
}

int leerPuntaje() {
	//complete la funcion
}

float calcularPromedio(Alumno prog[]) {
	//complete la funcion
}

int calcularMayor(Alumno prog[]) {
	//complete la funcion
}

int calcularMenor(Alumno prog[]) {
	//complete la funcion
}

int main() {
	cin >> N;
	*/ declare una variable prog del tipo Alumno */
    cout << "\nIngrese el codigo, parcial 1, parcial 2 y examen final: ";
	for(int i=0; i<N; i++) {
		cout << "\nAlumno " << i+1 << ": ";
		*/ lea el código del alumno*/
		
		prog[i].P1 = leerPuntaje();
		*/ lea los demás puntajes de forma similar */
        
        */ calcule el puntaje final PF */
		
		*/ calcule la nota final NF llamando a la funcion calcularNotaFinal */
		
		cout << endl << "PF: " << prog[i].PF << " NF: " << prog[i].NF;
	}
	
	cout << "\nPromedio de Notas: " << calcularPromedio(*/ complete los parametros */);
	cout << "\nMayor Nota: " << calcularMayor(*/ complete los parametros */);
	cout << "\nMenor Nota: " << calcularMenor(*/ complete los parametros */);
	return 0;
}
