#include<iostream>
using namespace std;
int leeInt( );
void impMat(int m, int n, float *mat);//no modificar el prototipado
void cargarmatriz(int m, int n, float *mat,float *matamp);//no modificar el prototipado
void maymenprom(int m,int n, int i, int &may, int &men, float &prom,float *mat);//no modificar el prototipado
int main()
{ int i, j, k, m, n,mayor,menor;float promedio;
  
  
  m = leeInt( );  //no modificar esta parte
  n = leeInt( );//no modificar esta parte
  float mat1[m][n],matamp[m][n+3];
  cargarmatriz(/*completar con los argumentos faltantes*/);
  for(i=0;i<m;i++)
  	{
  	maymenprom(/*completar con los argumentos faltantes*/);
  	matamp[i][n]=mayor;//retornado por referencia, no modificar esta parte
  	matamp[i][n+1]=menor;//retornado por referencia, no modificar esta parte
  	matamp[i][n+2]=promedio;//retornado por referencia, no modificar esta parte
	}
	impMat( m, n+3, &matamp[0][0] );
  	return(0);
}
int leeInt()//no modificar esta funcion
{ float kf;
  do {
     cin >> kf;  }
     while ( kf != int(kf )|| kf <= 0 );
   return int(kf);
}
void maymenprom(int m,int n, int i, int &may, int &men, float &prom,float *mat)//desarrollar la funcion
{
    
    
    
}
void cargarmatriz(int m, int n, float *mat,float *matamp)//desarrollar la funcion
{ 
   
   
}
void impMat( int m, int n, float *mat )//no modificar esta funcion
{  int i, j,k;
  k = 0;
   for ( i = 0; i < m; i++ )
   {  
      for ( j = 0; j < n; j++ )
      	{  
         cout << *(mat+n*i+j)<< "\n";  
		}  
	}
}