#include<iostream>
#include<cmath>
using namespace std;

/*Función que devuelve el resultado de a^b.
Se supone que b es un número no-negativo.*/
int potencia(int a, int b){
    int i, p=1;
    for(i=0;i<b;i++) p*=a;
    return p;
}

/*Función que devuelve true si el número n es primo, y false en caso contrario.
Se supone que n es positivo.*/
bool esPrimo(int n){
    if(n==1) return false;
    int i;
    for(i=2;i<=sqrt(n);i++) if(n%i==0) return false;
    return true;
}

/*Función que devuelve la cantidad de dígitos de un número n.
Se supone que n es positivo.*/
int cantDigitos(int n){
    int dig=0;
    while(n>0){
        dig++;
        n/=10;
    }
    return dig;
}

/*Función solicitada para el problema planteado.*/
/*completar*/ cantPrimos_C_Digitos(/*completar*/){
    //Escribir
    //aquí
    //la solución
}

/*Función principal: no modificar */
int main(){
    int N,C;
    cin>>N>>C;
    cout<<"Cantidad de primos de "<<C<<" digitos: "<<cantPrimos_C_Digitos(N,C)<<endl;
    return 0;
}