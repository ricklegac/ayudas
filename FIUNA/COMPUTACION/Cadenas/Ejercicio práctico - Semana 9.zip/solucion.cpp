#include<iostream>
#include<cstring>
using namespace std;
#define TAMMAXCAD 1001

int main(){
    //IMPLEMENTAR
    return 0;
}
